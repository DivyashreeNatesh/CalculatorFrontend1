import { Component, OnInit } from '@angular/core';

import { ApigoogleService, UserInfo } from '../apigoogle.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  title = 'angular-google-login-example';
  userInfo: UserInfo;

  constructor(public google: ApigoogleService) {
    google.userProfileSubject.subscribe(info => {
      this.userInfo = info
    })
  }
  ngOnInit(): void {
    this.signInWithGoogle
  }

  isLoggedIn(): boolean {
    return this.google.isLoggedIn()
  }

  logout() {
    this.google.signOut()
  }

  signInWithGoogle() {
    this.google.signInWithGoogle()
  }

}
