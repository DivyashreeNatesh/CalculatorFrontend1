import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { StorageService } from '../storage.service';
import { Router } from '@angular/router';
import { ApigoogleService, UserInfo } from '../apigoogle.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit{

  title = 'angular-google-login-example';
  userInfo!: UserInfo;


  ngOnInit(): void {
    if(this.storageService.isLoggedIn())
    {
      this.isLoggedIn= true;
      this.roles= this.storageService.getUser().roles;
    }
   
  }
  

  form:any ={
    username:null,
    password:null
  };
  isLoggedIn = false;
  isLoginFailed = false;
  errorMessage='';
  roles:string[] =[];
  username:any;

  constructor(private authService:AuthService, private storageService:StorageService, private router:Router,public google: ApigoogleService)
  {google.userProfileSubject.subscribe(info => {
    this.userInfo = info
  })}

  hide = true;

  onSubmit():void{
    const{ username, password}= this.form;
    this.authService.login(username, password).subscribe({
      next:data =>{
        this.storageService.saveUser(data);

        this.isLoginFailed=false;
        this.isLoggedIn = true;
       // this.roles = this.storageService.getUser().roles;
       // this.reloadPage();
       this.username= username;
       alert(`welcome ,${this.username}`)
       //this.toastr.success(`welcome ,${this.username}`);
        this.redirectToPage();
      },
      error:err => {
        this.errorMessage = err.error.message;
        this.isLoginFailed=true;
      }
    });
  }

  reloadPage():void{
    window.location.reload();
  }
  redirectToPage() {
    this.router.navigate(['/percentage']);
  }

  isLoggedIn1(): boolean {
    return this.google.isLoggedIn()
  }

  logout() {
    this.google.signOut()
  }

  signInWithGoogle() {
    this.google.signInWithGoogle()
    
  }


}
