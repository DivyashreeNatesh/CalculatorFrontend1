import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Currencycalculator } from './Models/Calc';

@Injectable({
  providedIn: 'root'
})
export class CurrencyserviceService {

    private url: string =" http://localhost:7866/CurrencyConvert/getCurrency";

    private PUrl:string="http://localhost:7001/CurrencyConvert/create";
   
     constructor(private http:HttpClient) { }
   
     getHistory()
     {
       return this.http.get<Currencycalculator[]>(this.url)
     }
   
     addrecord(data:Currencycalculator)
     {
       return this.http.post<Currencycalculator>(`${this.PUrl}`,data)
     }
   
   }
   
   
