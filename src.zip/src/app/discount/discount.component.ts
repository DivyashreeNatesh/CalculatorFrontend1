import { Component, OnInit } from '@angular/core';
import { Discount } from '../Models/discount';
import { PercentageService } from '../percentage.service';

@Component({
  selector: 'app-discount',
  templateUrl: './discount.component.html',
  styleUrls: ['./discount.component.css']
})
export class DiscountComponent implements OnInit {

  discountCalculator=new Discount();
  showTotal=false;

  constructor( private percentageCalservice: PercentageService ){
    
  }

  ngOnInit(): void {
   
  }

  onSubmit1()
  {
    console.log("inside component", this.discountCalculator);
    const obj = this;
    obj.percentageCalservice.addRecord1(obj.discountCalculator).subscribe(data => {
      console.log(data);
      obj.discountCalculator.finalBill = data.finalBill;
      obj.discountCalculator.afterDiscount = data.afterDiscount;
      obj.discountCalculator.discountAmount = data.discountAmount;
      obj.discountCalculator.afterTax = data.afterTax;
      obj.discountCalculator.aftertaxAmount = data.aftertaxAmount;
      obj.showTotal = true;
    })
  //  alert('')
  }

}
