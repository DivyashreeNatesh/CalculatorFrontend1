import { TestBed } from '@angular/core/testing';

import { ApigoogleService } from './apigoogle.service';

describe('ApigoogleService', () => {
  let service: ApigoogleService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ApigoogleService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
