export class Currencycalculator {
    id: number;
    fromCurrency: string;
    toCurrency: string;
    excRate: number;
    convertedAmount: number;

} 