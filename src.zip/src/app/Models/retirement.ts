export class RetirementCalculator {

    id: number;
    currentAge: number;
    currentSavings: number;
    annualReturn: number;
    monthlyContribute: number;
    total: number;
}
export class NonRetirementCalculator {

    id: number;
    currentAge: number;
    currentSavings: number;
    annualReturn: number;
    monthlyContribute: number;
    total: number;
}

