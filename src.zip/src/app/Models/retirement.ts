export class RetirementCalculator {

    id: number;
    currentAge: number;
    currentSavings: number;
    annualReturn: number;
    monthlyContribute: number;
    total: number;
    formattedTotal:string;
}
export class NonRetirementCalculator {

    id: number;
    currentAge: number;
    currentSavings: number;
    annualReturn: number;
    monthlyContribute: number;
    total: number;
    formattedTotal:string;
}

