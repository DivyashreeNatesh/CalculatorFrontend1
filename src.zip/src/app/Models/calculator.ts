export class Calculator {

    id: number;
    name: string;
    sub1: number;
    sub2: number;
    sub3: number;
    sub4: number;
    sub5: number;
    sub6: number;
    maxMarks: number;
    obtainedMarks:number;
	averageMarks:number;
    percentage:number;

}

