
export class Discount{
    id: number;
    itemName: string;
    originalPrice: number;
    discountPercentage: number;
    shippingCharges: number;
    finalBill: number;
    afterDiscount: number;
    discountAmount: number;
    afterTax: number;
    taxPercentage: number;
    aftertaxAmount: number;
}