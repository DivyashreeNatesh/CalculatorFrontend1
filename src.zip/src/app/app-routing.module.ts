import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { PercentageComponent } from './percentage/percentage.component';
import { CurrencyComponent } from './currency/currency.component';
import { RetirementComponent } from './retirement/retirement.component';
import { StudentComponent } from './student/student.component';
import { DiscountComponent } from './discount/discount.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { StudenthistoryComponent } from './studenthistory/studenthistory.component';
import { CurrencyhistoryComponent } from './currencyhistory/currencyhistory.component';
import { RetirementhistoryComponent } from './retirementhistory/retirementhistory.component';
import { NongovernmenthistoryComponent } from './nongovernmenthistory/nongovernmenthistory.component';
import { NongovermentComponent } from './nongoverment/nongoverment.component';
import { DiscounthistoryComponent } from './discounthistory/discounthistory.component';
import { NavbarComponent } from './navbar/navbar.component';
import { SignupComponent } from './signup/signup.component';
import { HomenavComponent } from './homenav/homenav.component';


const routes: Routes = [
  {path:"percentage", component:PercentageComponent},
  {path:"login",component:LoginComponent},
  {path:"currency", component:CurrencyComponent},
  {path:"retirement",component:RetirementComponent},
  {path:"nongovernment",component:NongovermentComponent},
  {path:"student",component:StudentComponent},
  {path:"discount",component:DiscountComponent},
  {path:"aboutus",component:AboutusComponent},
  {path:"studenthistory",component:StudenthistoryComponent},
  {path:"discounthistory",component:DiscounthistoryComponent},
  {path:"currencyhistory",component:CurrencyhistoryComponent},
  {path:"retirementhistory",component:RetirementhistoryComponent},
  {path:"nongovermenthistory",component:NongovernmenthistoryComponent},
  {path:"navbar",component:NavbarComponent},
  {path:"signup",component:SignupComponent},
  {path:"",component:HomenavComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
