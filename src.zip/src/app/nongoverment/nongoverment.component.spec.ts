import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NongovermentComponent } from './nongoverment.component';

describe('NongovermentComponent', () => {
  let component: NongovermentComponent;
  let fixture: ComponentFixture<NongovermentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NongovermentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NongovermentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
