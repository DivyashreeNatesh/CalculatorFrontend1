import { Component, OnInit } from '@angular/core';
import { RetirementService } from '../retirement.service';
import { NonRetirementCalculator } from '../Models/retirement';

@Component({
  selector: 'app-nongoverment',
  templateUrl: './nongoverment.component.html',
  styleUrls: ['./nongoverment.component.css']
})
export class NongovermentComponent  implements OnInit {

  Nongovernmentcalculator = new NonRetirementCalculator();
  showformattedTotal = false;

  Nongovernment:NonRetirementCalculator[]=[];

  constructor(private retirementService: RetirementService) {

  }
  ngOnInit(): void {

  }
 
  onSubmit4()
  {
    console.log("inside component", this.Nongovernmentcalculator);
    const obj = this;
    obj.retirementService.addRecord1(obj. Nongovernmentcalculator).subscribe(data => {
      console.log(data);
      obj. Nongovernmentcalculator.formattedTotal = data.formattedTotal;
      obj.showformattedTotal = true;
    })
  }
}
