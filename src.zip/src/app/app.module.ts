import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { PercentageComponent } from './percentage/percentage.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatIconModule } from '@angular/material/icon';
import { GoogleLoginProvider, SocialAuthServiceConfig, SocialLoginModule } from 'angularx-social-login';
import { OAuthModule } from 'angular-oauth2-oidc';
import {MatTabsModule} from '@angular/material/tabs';
import {MatCardModule} from '@angular/material/card';
import {MatButtonModule} from '@angular/material/button';
import {MatToolbarModule} from '@angular/material/toolbar';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDialogModule } from '@angular/material/dialog';
import { MatListModule } from '@angular/material/list';
import { CurrencyComponent } from './currency/currency.component';
import { RetirementComponent } from './retirement/retirement.component';
import { StudentComponent } from './student/student.component';
import { DiscountComponent } from './discount/discount.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { StudenthistoryComponent } from './studenthistory/studenthistory.component';
import { DiscounthistoryComponent } from './discounthistory/discounthistory.component';
import { CurrencyhistoryComponent } from './currencyhistory/currencyhistory.component';
import { RetirementhistoryComponent } from './retirementhistory/retirementhistory.component';
import { NongovernmenthistoryComponent } from './nongovernmenthistory/nongovernmenthistory.component';
import { NongovermentComponent } from './nongoverment/nongoverment.component';
import {MatTableModule} from '@angular/material/table';
import { NavbarComponent } from './navbar/navbar.component';
import { MatMenuModule } from '@angular/material/menu';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { HomenavComponent } from './homenav/homenav.component';





@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,    
    PercentageComponent,
    CurrencyComponent,
    RetirementComponent,
    StudentComponent,
    DiscountComponent,
    AboutusComponent,
    StudenthistoryComponent,
    DiscounthistoryComponent,
    CurrencyhistoryComponent,
    RetirementhistoryComponent,
    NongovernmenthistoryComponent,
    NongovermentComponent,
    NavbarComponent,
    HomenavComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatIconModule,
    OAuthModule.forRoot(),
    MatTabsModule,
    MatCardModule,
    MatButtonModule,
    MatToolbarModule,
    MatCardModule,
    MatSelectModule,
    MatInputModule,
    MatDialogModule,
    MatListModule,
    MatTableModule,
    MatMenuModule
  ],
  providers: [
    {
      provide:'SocialAuthServiceConfig',
      useValue:{
        autoLogin:false,
        providers:[
          {
            id:GoogleLoginProvider.PROVIDER_ID,
            provider: new GoogleLoginProvider(
              ''),
          },
        ],
      } as SocialAuthServiceConfig,
    },
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
