import { Component, OnInit } from '@angular/core';
import { RetirementCalculator } from '../Models/retirement';
import { RetirementService } from '../retirement.service';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-retirementhistory',
  templateUrl: './retirementhistory.component.html',
  styleUrls: ['./retirementhistory.component.css']
})
export class RetirementhistoryComponent  implements OnInit {

  retirementret : RetirementCalculator[] = [];
  dataSource:MatTableDataSource<RetirementCalculator> = new MatTableDataSource();

  displayedColumns: string[] =['id','currentAge','currentSavings','annualReturn','monthlyContribute','formattedTotal']


  constructor(private retirement:RetirementService) {

    this.dataSource = new MatTableDataSource();

  }

  ngOnInit(): void {

    this.getHistory();
  }

  getHistory() {

    this.retirement.getHistory().subscribe({

      next: (res) => { 
        this.dataSource.data = res;
        console.log(res);
       },



    })


  }

}
