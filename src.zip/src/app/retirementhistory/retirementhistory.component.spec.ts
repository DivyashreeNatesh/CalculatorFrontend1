import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RetirementhistoryComponent } from './retirementhistory.component';

describe('RetirementhistoryComponent', () => {
  let component: RetirementhistoryComponent;
  let fixture: ComponentFixture<RetirementhistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RetirementhistoryComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RetirementhistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
