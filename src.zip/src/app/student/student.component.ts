import { Component, OnInit } from '@angular/core';
import { Calculator } from '../Models/calculator';
import { PercentageService } from '../percentage.service';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {

  percentageCalculator=new Calculator();
  showTotal=false;

  constructor( private percentageCalservice: PercentageService ){
    
  }

  ngOnInit(): void {
  }
  onSubmit()
  {
    console.log("inside component", this.percentageCalculator);
    const obj = this;
    obj.percentageCalservice.addRecord(obj.percentageCalculator).subscribe(data => {
      console.log(data);
      obj.percentageCalculator.obtainedMarks = data.obtainedMarks;
      obj.percentageCalculator.averageMarks = data.averageMarks;
      obj.percentageCalculator.percentage = data.percentage;
      obj.showTotal = true;
    })
  //  alert('')
  }

}
