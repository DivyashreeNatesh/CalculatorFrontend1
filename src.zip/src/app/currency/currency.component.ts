import { Component, OnInit } from '@angular/core';
import { Currencycalculator } from '../Models/Calc';
import { CurrencyserviceService } from '../currencyservice.service';

@Component({
  selector: 'app-currency',
  templateUrl: './currency.component.html',
  styleUrls: ['./currency.component.css']
})
export class CurrencyComponent implements OnInit {

  currencyCalculator = new Currencycalculator();
  showTotal = false;

  currencycalc:Currencycalculator[]=[];

  constructor(private currencyservice: CurrencyserviceService) {

  }
  ngOnInit(): void {

  }
  getHistory() {

    this.currencyservice.getHistory().subscribe({

      next: (res) => { this.currencycalc = res },



    })



  }
  onSubmit2() {
    console.log("inside component", this.currencyCalculator);
    const obj = this;
    obj.currencyservice.addrecord(obj.currencyCalculator).subscribe(data => {
      console.log(data);
      obj.currencyCalculator.convertedAmount = data.convertedAmount;
      obj.showTotal = true;
    })
    //  alert('')
  }
}
