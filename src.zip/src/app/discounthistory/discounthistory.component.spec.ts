import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DiscounthistoryComponent } from './discounthistory.component';

describe('DiscounthistoryComponent', () => {
  let component: DiscounthistoryComponent;
  let fixture: ComponentFixture<DiscounthistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DiscounthistoryComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DiscounthistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
