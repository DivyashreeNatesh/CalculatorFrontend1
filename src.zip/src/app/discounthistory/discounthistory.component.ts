import { Component, OnInit } from '@angular/core';
import { Discount } from '../Models/discount';
import { PercentageService } from '../percentage.service';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-discounthistory',
  templateUrl: './discounthistory.component.html',
  styleUrls: ['./discounthistory.component.css']
})
export class DiscounthistoryComponent  implements OnInit {

  discountdis: Discount[] = [];
  dataSource:MatTableDataSource<Discount> = new MatTableDataSource();

  displayedColumns: string[] =['id','itemName','originalPrice','discountPercentage','shippingCharges','afterDiscount','discountAmount','taxPercentage','afterTax','aftertaxAmount']



  constructor(private PercentageService: PercentageService) {

    this.dataSource = new MatTableDataSource();

  }

  ngOnInit(): void {

    this.getHistory1();
  }

  getHistory1() {

    this.PercentageService.getHistory1().subscribe({

      next: (res) => { 
        this.dataSource.data = res;
        console.log(res);
      },

    })

  }
}

