import { HTTP_INTERCEPTORS, HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';

import { Observable, catchError, throwError } from 'rxjs';
import { StorageService } from './storage.service';
import { EventBusService } from './event/event-bus.service';
import { EventData } from './event/event.class';
import { Injectable } from '@angular/core';

@Injectable()
export class HttpRequestInterceptor implements  HttpInterceptor {

  private isRefreshing = false;

  constructor(private storageService:StorageService, private eventBusService:EventBusService) { }
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    req = req.clone({
      withCredentials:true,
    });
    return next.handle(req).pipe(
      catchError((error) =>
      {
        if(
          error instanceof HttpErrorResponse && !req.url.includes('auth/signin')&&
          error.status===401
        )
        {
          return this.handle401Error(req,next);
        }
        return throwError(() => error);
      })
    );
  }

  private handle401Error(request: HttpRequest<unknown>, next: HttpHandler) {

    if (!this.isRefreshing){
      this.isRefreshing = true;

      if(this.storageService.isLoggedIn()){
        this.eventBusService.emit(new EventData('logout',null));
      }
    }
   return next.handle(request);
  }

}
export const HttpInterceptorProvider = [
  { provide: HTTP_INTERCEPTORS, useClass : HttpRequestInterceptor, multi:true},
];
