import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Calculator } from './Models/calculator';
import { Discount } from './Models/discount';


@Injectable({
  providedIn: 'root'
})
export class PercentageService {

  private PUrl1:string="http://localhost:7000/discount/create";
 private PUrl:string="http://localhost:7000/students/create";
 
  private Purl2:string="http://localhost:7000/students/getStudents";
  private purl3:string="http://localhost:7000/discount/get";

  constructor(private http:HttpClient) { }


  addRecord(data:Calculator)
  {
    return this.http.post<Calculator>(`${this.PUrl}`,data)
  }

  addRecord1(data:Discount)
  {
    return this.http.post<Discount>(`${this.PUrl1}`,data)
  }
  
  getHistory()
  {
    return this.http.get<Calculator[]>(this.Purl2)
  }
  getHistory1()
  {
    return this.http.get<Discount[]>(this.purl3)
  }

  
}


