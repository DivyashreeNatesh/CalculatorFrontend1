import { Component, OnInit } from '@angular/core';
import { Calculator } from '../Models/calculator';
import { PercentageService } from '../percentage.service';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-studenthistory',
  templateUrl: './studenthistory.component.html',
  styleUrls: ['./studenthistory.component.css']
})

export class StudenthistoryComponent  implements OnInit {

  studentstud: Calculator[] = [];
  dataSource:MatTableDataSource<Calculator> = new MatTableDataSource();

  displayedColumns: string[] =['id','name','sub1','sub2','sub3','sub4','sub5','sub6','maxMarks','obtainedMarks','averageMarks','percentage']



  constructor(private PercentageService:PercentageService) {

    this.dataSource = new MatTableDataSource();


  }

  ngOnInit(): void {

    this.getHistory();
  }

  getHistory() {

    this.PercentageService.getHistory().subscribe({

      next: (res) => {
         this.dataSource.data = res;
         console.log(res);
        },



    })


  }

}
