import { Component, OnInit } from '@angular/core';
import { Calculator } from '../Models/calculator';
import { PercentageService } from '../percentage.service';
import { FormGroup } from '@angular/forms';
import { Discount } from '../Models/discount';
import { Currencycalculator } from '../Models/Calc';
import { CurrencyserviceService } from '../currencyservice.service';
import { ApigoogleService } from '../apigoogle.service';
import { NonRetirementCalculator, RetirementCalculator } from '../Models/retirement';
import { RetirementService } from '../retirement.service';
import { AuthService } from '../auth.service';



@Component({
  selector: 'app-percentage',
  templateUrl: './percentage.component.html',
  styleUrls: ['./percentage.component.css']
})
export class PercentageComponent implements OnInit {
  
  percentageCalculator=new Calculator();
  discountCalculator=new Discount();
  currencyCalculator=new Currencycalculator();
  
  retirementCalculator=new RetirementCalculator();
  NonGovernment= new NonRetirementCalculator();
  discountcalculator: Discount[] = [];
  calculator: Calculator[] = [];
  convertedRecord: FormGroup;
  //convertedAmount:number;
  showTotal=false;

  constructor(private percentageCalservice: PercentageService, 
    private currencyservice: CurrencyserviceService,private retirementservice:RetirementService,
    public google: ApigoogleService, private authService:AuthService) { }

  ngOnInit(): void {

  }
  addRecords() {

    this.percentageCalservice.addRecord(this.percentageCalculator).subscribe({
      next: (data) => {
        console.log(data);
        
      },
      error: (e) => {
        console.log(e);
      }
    });
  }

  onSubmit()
  {
    console.log("inside component", this.percentageCalculator);
    const obj = this;
    obj.percentageCalservice.addRecord(obj.percentageCalculator).subscribe(data => {
      console.log(data);
      obj.percentageCalculator.obtainedMarks = data.obtainedMarks;
      obj.percentageCalculator.averageMarks = data.averageMarks;
      obj.percentageCalculator.percentage = data.percentage;
      obj.showTotal = true;
    })
  //  alert('')
  }


  onSubmit1()
  {
    console.log("inside component", this.discountCalculator);
    const obj = this;
    obj.percentageCalservice.addRecord1(obj.discountCalculator).subscribe(data => {
      console.log(data);
      obj.discountCalculator.finalBill = data.finalBill;
      obj.discountCalculator.afterDiscount = data.afterDiscount;
      obj.discountCalculator.discountAmount = data.discountAmount;
      obj.discountCalculator.afterTax = data.afterTax;
      obj.discountCalculator.aftertaxAmount = data.aftertaxAmount;
      obj.showTotal = true;
    })
  //  alert('')
  }

  onSubmit2()
  {
    console.log("inside component", this.currencyCalculator);
    const obj = this;
    obj.currencyservice.addrecord(obj.currencyCalculator).subscribe(data => {
      console.log(data);
      obj.currencyCalculator.convertedAmount = data.convertedAmount;
      obj.showTotal = true;
    })
  //  alert('')
  }

  onSubmit3()
  {
    console.log("inside component", this. retirementCalculator);
    const obj = this;
    obj.retirementservice.addRecord(obj. retirementCalculator).subscribe(data => {
      console.log(data);
      obj. retirementCalculator.total = data.total;
      obj.showTotal = true;
    })

    
  //  alert('')
  }


  // get()
  // {
  //   this.percentageCalculator.getHistory().subscribe(res =>
  //     {
  //       this.calculator = res;
  //      // console.log(res);
  //       if(this.percentageCalculator.id === this.percentageCalculator.id)
  //       {
  //         console.log(res);
  //       }
  //     })
  // }
  signout() {
    this.google.signOut()
  }

  logout()
  {
    this.authService.logout();
  }
}

