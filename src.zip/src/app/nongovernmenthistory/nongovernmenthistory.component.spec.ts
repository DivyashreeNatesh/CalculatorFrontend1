import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NongovernmenthistoryComponent } from './nongovernmenthistory.component';

describe('NongovernmenthistoryComponent', () => {
  let component: NongovernmenthistoryComponent;
  let fixture: ComponentFixture<NongovernmenthistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NongovernmenthistoryComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NongovernmenthistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
