import { Component, OnInit } from '@angular/core';
import { NonRetirementCalculator } from '../Models/retirement';
import { RetirementService } from '../retirement.service';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-nongovernmenthistory',
  templateUrl: './nongovernmenthistory.component.html',
  styleUrls: ['./nongovernmenthistory.component.css']
})
export class NongovernmenthistoryComponent  implements OnInit {

  Nongovernmentnon: NonRetirementCalculator[] = [];
  dataSource:MatTableDataSource<NonRetirementCalculator> = new MatTableDataSource();
  displayedColumns: string[] =['id','currentAge','currentSavings','annualReturn','monthlyContribute','formattedTotal']

  constructor(private RetirementService:RetirementService) {

    this.dataSource = new MatTableDataSource();


  }

  ngOnInit(): void {

    this.getHistory1();
  }

  getHistory1() {

    this.RetirementService.getHistory1().subscribe({

      next: (res) => {
         this.dataSource.data = res;
         console.log(res);
         },

    })

  }

}


