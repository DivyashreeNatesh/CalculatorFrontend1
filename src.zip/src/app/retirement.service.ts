import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NonRetirementCalculator, RetirementCalculator } from './Models/retirement';

@Injectable({
  providedIn: 'root'
})
export class RetirementService {

  private PUrl:string="http://localhost:7002/calculator1/insert";
  private PUrl1:string="http://localhost:7002/calculator1/noninsert";
  private Purl2:string="http://localhost:7002/calculator1/retirelist";
  private Purl3:string="http://localhost:7002/calculator1/Nonretirelist";
 
   constructor(private http:HttpClient) { }
 
 
   addRecord(data:RetirementCalculator)
   {
     return this.http.post<RetirementCalculator>(`${this.PUrl}`,data)
   }
 
   addRecord1(data:NonRetirementCalculator)
   {
     return this.http.post<NonRetirementCalculator>(`${this.PUrl1}`,data)
   }
   
   getHistory()
   {
     return this.http.get<RetirementCalculator[]>(this.Purl2)
   }
   getHistory1()
   {
     return this.http.get<NonRetirementCalculator[]>(this.Purl3)
   }
 
 
 }
 
