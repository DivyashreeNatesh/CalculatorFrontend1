import { Component, OnInit } from '@angular/core';
import { Currencycalculator } from '../Models/Calc';
import { CurrencyserviceService } from '../currencyservice.service';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-currencyhistory',
  templateUrl: './currencyhistory.component.html',
  styleUrls: ['./currencyhistory.component.css']
})
export class CurrencyhistoryComponent implements OnInit {

  currencycalc: Currencycalculator[] = [];
  dataSource:MatTableDataSource<Currencycalculator> = new MatTableDataSource();

  displayedColumns: string[] =['fromCurrency','toCurrency','excRate','convertedAmount']

  constructor(private currencyservice: CurrencyserviceService) {

    this.dataSource =  new MatTableDataSource();

  }

  ngOnInit(): void {

    this.getHistory();
  }

  getHistory() {

    this.currencyservice.getHistory().subscribe({

      next: (res) => {
         this.dataSource.data = res;
         console.log(res);
         },



    })


  }
}
