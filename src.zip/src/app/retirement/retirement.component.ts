import { Component, OnInit } from '@angular/core';
import { NonRetirementCalculator, RetirementCalculator } from '../Models/retirement';
import { RetirementService } from '../retirement.service';

@Component({
  selector: 'app-retirement',
  templateUrl: './retirement.component.html',
  styleUrls: ['./retirement.component.css']
})
export class RetirementComponent implements OnInit 
{

  retirementCalculator=new RetirementCalculator();
  showformattedTotal=false;
  constructor(private retirementservice:RetirementService){

  }
  
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

  onSubmit3()
  {
    console.log("inside component", this. retirementCalculator);
    const obj = this;
    obj.retirementservice.addRecord(obj. retirementCalculator).subscribe(data => {
      console.log(data);
      obj. retirementCalculator.formattedTotal = data.formattedTotal;
      obj.showformattedTotal = true;
    })
  }
}
